<?php
   echo "halo word";
?>