<?php$servername="db4free.net";
$username="sauruda165610081
$password="12345678";
// Create connection
$conn=new mysqli ($servername,$username,$password);
// Check connection
if 
   ($conn-connect_error){
	   die ("connection failed:".$conn->connect_error);
   }
   echo "Connected successfully from STMIK AKAKOM to".$servername.</br>";
 echo"  echo "Connection created by AHLINYA AHLI,master".$username;
   ?>